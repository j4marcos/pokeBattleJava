import javax.swing.*;

class Main {

    public static void main(String[] args) {
        JFrame frame = new JFrame("jogo");
        Quadrado panel = new Quadrado();

        frame.add(panel);
        frame.setSize(650, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
