import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.*;

public class Quadrado extends JPanel implements KeyListener {
    private int tamanho = 50;
    private int posicaoX = 300;
    private int posicaoY = 500;
    private Image img;

    public Quadrado() {
        setFocusable(true);
        addKeyListener(this);
        try {
            Image file = ImageIO.read(new File("nave.png"));
            img = file.getScaledInstance(tamanho, tamanho, Image.SCALE_SMOOTH);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
   
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(img, posicaoX, posicaoY, this);
    }

    public void keyPressed(KeyEvent e) {
        // a largura da tela é 650
        if (e.getKeyCode() == KeyEvent.VK_RIGHT && posicaoX < 570) {
            posicaoX += 10;
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT && posicaoX > 10) {
            posicaoX -= 10;
        }

        repaint();
    }

    public void keyTyped(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}
}
